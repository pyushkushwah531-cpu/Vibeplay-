/* VibePlay starter app
   Replace the example YouTube IDs below with videos that allow embedding.
   No login or backend: preferences are stored only in this browser's LocalStorage.
*/
const VIDEO_DATA = [
  {id:"long-1",title:"Science और Technology की दुनिया",youtubeId:"M7lc1UVf-VE",type:"long",category:"Technology",channel:"VibePlay Picks",description:"Technology से जुड़ी एक वीडियो। अपना पसंदीदा Embed Link यहाँ जोड़ें।",duration:600,addedAt:"2026-10-24"},
  {id:"long-2",title:"पढ़ाई में Focus कैसे बनाएँ",youtubeId:"ysz5S6PUM-U",type:"long",category:"Motivation",channel:"Study Zone",description:"Focus और learning से जुड़ी वीडियो।",duration:720,addedAt:"2026-10-23"},
  {id:"long-3",title:"Gaming Highlights",youtubeId:"ScMzIvxBSi4",type:"long",category:"Gaming",channel:"Play Hub",description:"Gaming की एक sample video।",duration:480,addedAt:"2026-10-22"},
  {id:"long-4",title:"Space के रोचक तथ्य",youtubeId:"aqz-KE-bpKQ",type:"long",category:"Education",channel:"Curious Mind",description:"Space और science के बारे में जानें।",duration:900,addedAt:"2026-10-21"},
  {id:"short-1",title:"एक मिनट का Tech Fact",youtubeId:"M7lc1UVf-VE",type:"short",category:"Technology",channel:"Vibe Shorts",description:"Technology का छोटा सा fact।",duration:60,addedAt:"2026-10-24"},
  {id:"short-2",title:"आज की Motivation",youtubeId:"ysz5S6PUM-U",type:"short",category:"Motivation",channel:"Daily Boost",description:"एक छोटा motivational break।",duration:45,addedAt:"2026-10-23"},
  {id:"short-3",title:"Gaming Moment",youtubeId:"ScMzIvxBSi4",type:"short",category:"Gaming",channel:"Play Shorts",description:"Gaming से जुड़ा short clip।",duration:35,addedAt:"2026-10-22"},
  {id:"short-4",title:"Space Fact",youtubeId:"aqz-KE-bpKQ",type:"short",category:"Education",channel:"Quick Learn",description:"Space की एक छोटी जानकारी।",duration:50,addedAt:"2026-10-21"}
];

const STORE = {
  likes: "vibeplay_likes_v1",
  history: "vibeplay_history_v1",
  saves: "vibeplay_saves_v1",
  topics: "vibeplay_topics_v1",
  progress: "vibeplay_progress_v1",
  skips: "vibeplay_skips_v1"
};
const $ = (sel, root=document) => root.querySelector(sel);
const $$ = (sel, root=document) => [...root.querySelectorAll(sel)];
const read = (key, fallback) => { try { const v=localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch { return fallback; } };
const write = (key, value) => { try { localStorage.setItem(key, JSON.stringify(value)); } catch(e) { console.warn("LocalStorage unavailable", e); } };
let likes = read(STORE.likes, []);
let history = read(STORE.history, {});
let saves = read(STORE.saves, []);
let topics = read(STORE.topics, {});
let progress = read(STORE.progress, {});
let skips = read(STORE.skips, {});
let activeCategory = "All";
let sortMode = "mixed";
let currentVideo = null;
let longPlayer = null;
let shortPlayers = new Map();
let viewBeforePlayer = "home";
let pendingInstallPrompt = null;
let watchTimer = null;
let lastShortId = null;

const categories = ["All", ...new Set(VIDEO_DATA.map(v=>v.category))];
const getVideo = id => VIDEO_DATA.find(v=>v.id===id);
const thumb = v => `https://img.youtube.com/vi/${encodeURIComponent(v.youtubeId)}/hqdefault.jpg`;
const formatDuration = sec => {
  sec = Math.max(0, Number(sec)||0);
  return `${Math.floor(sec/60)}:${String(Math.floor(sec%60)).padStart(2,"0")}`;
};
const isLiked = id => likes.includes(id);
const isSaved = id => saves.includes(id);

function persistAll(){
  write(STORE.likes,likes); write(STORE.history,history); write(STORE.saves,saves);
  write(STORE.topics,topics); write(STORE.progress,progress); write(STORE.skips,skips);
}
function escapeHTML(s=""){
  return String(s).replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function scoreVideo(v){
  const h=history[v.id]||{};
  const watchRatio = h.duration ? Math.min(1,(h.watchedSeconds||0)/h.duration) : 0;
  const topicScore = Number(topics[v.category]||0);
  const ageDays = Math.max(0,(Date.now()-new Date(v.addedAt+"T00:00:00").getTime())/86400000);
  const recency = Math.max(0, 4-ageDays*.45);
  const unseenBonus = h.watchedSeconds ? 0 : 1.8;
  const likedBonus = isLiked(v.id) ? 2 : 0;
  const completionBonus = watchRatio >= .8 ? 3 : watchRatio >= .3 ? 1.5 : 0;
  const skipPenalty = Math.min(5,Number(skips[v.id]||0)*1.5);
  return topicScore + recency + unseenBonus + likedBonus + completionBonus - skipPenalty;
}
function orderedVideos(list){
  const copy=[...list];
  if(sortMode==="latest") return copy.sort((a,b)=>new Date(b.addedAt)-new Date(a.addedAt));
  return copy.sort((a,b)=>scoreVideo(b)-scoreVideo(a) || new Date(b.addedAt)-new Date(a.addedAt));
}
function cardHTML(v){
  const h=history[v.id]||{};
  const seen=h.watchedSeconds ? ` • ${Math.min(100,Math.round((h.watchedSeconds/(h.duration||v.duration||1))*100))}% देखा` : "";
  return `<article class="video-card" tabindex="0" role="button" data-open-video="${escapeHTML(v.id)}" aria-label="Play ${escapeHTML(v.title)}">
    <div class="thumb-wrap"><img loading="lazy" src="${thumb(v)}" alt="" onerror="this.style.opacity='.2'">
      <span class="card-type">${v.type==="short"?"SHORT":"VIDEO"}</span><span class="duration">${formatDuration(v.duration)}</span>
    </div>
    <div class="card-info"><div class="channel-avatar">${escapeHTML((v.channel||"V")[0].toUpperCase())}</div>
      <div class="card-copy"><h3>${escapeHTML(v.title)}</h3><p>${escapeHTML(v.channel)} · ${escapeHTML(v.category)}${seen}</p></div>
      <div class="card-actions"><button class="mini-action ${isLiked(v.id)?"liked":""}" data-like="${escapeHTML(v.id)}" aria-label="Like" title="Like">${isLiked(v.id)?"♥":"♡"}</button></div>
    </div>
  </article>`;
}
function renderChips(){
  $("#categoryChips").innerHTML=categories.map(c=>`<button type="button" class="chip ${c===activeCategory?"active":""}" data-category="${escapeHTML(c)}">${escapeHTML(c==="All"?"सभी":c)}</button>`).join("");
}
function renderHome(){
  renderChips();
  const query=$("#searchInput").value.trim().toLowerCase();
  let list=VIDEO_DATA.filter(v=>v.type==="long");
  if(activeCategory!=="All") list=list.filter(v=>v.category===activeCategory);
  if(query) list=list.filter(v=>`${v.title} ${v.category} ${v.channel} ${v.description}`.toLowerCase().includes(query));
  list=orderedVideos(list);
  $("#videoGrid").innerHTML=list.map(cardHTML).join("");
  $("#emptyHome").hidden=list.length>0;
}
function renderCollection(view, ids, emptySelector, gridSelector){
  const query=$("#searchInput").value.trim().toLowerCase();
  let list=ids.map(getVideo).filter(Boolean);
  if(query) list=list.filter(v=>`${v.title} ${v.category} ${v.channel}`.toLowerCase().includes(query));
  $(gridSelector).innerHTML=list.map(cardHTML).join("");
  $(emptySelector).hidden=list.length>0;
}
function renderLiked(){renderCollection("liked",[...likes].reverse(),"#emptyLiked","#likedGrid");}
function renderHistory(){
  const ids=Object.entries(history).sort((a,b)=>(b[1].lastSeen||0)-(a[1].lastSeen||0)).map(([id])=>id);
  renderCollection("history",ids,"#emptyHistory","#historyGrid");
}
function renderAll(){renderHome();renderLiked();renderHistory();}

function navigate(view){
  const map={home:"#homeView",shorts:"#shortsView",liked:"#likedView",history:"#historyView",profile:"#profileView"};
  Object.entries(map).forEach(([key,sel])=>$(sel).hidden=key!==view);
  $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
  document.body.classList.toggle("is-shorts",view==="shorts");
  if(view==="shorts") renderShorts();
  if(view==="home") renderHome();
  if(view==="liked") renderLiked();
  if(view==="history") renderHistory();
  if(view==="shorts" && shortPlayers.size===0) startVisibleShort();
  window.scrollTo({top:0,behavior:"smooth"});
}

function addWatch(id, seconds=0, duration=0){
  const v=getVideo(id); if(!v) return;
  const old=history[id]||{watchedSeconds:0,duration:duration||v.duration||0};
  old.watchedSeconds=Math.max(Number(old.watchedSeconds)||0,Number(seconds)||0);
  old.duration=duration||old.duration||v.duration||0;
  old.lastSeen=Date.now();
  history[id]=old;
  const ratio=old.duration?old.watchedSeconds/old.duration:0;
  if(ratio>=.8) topics[v.category]=(topics[v.category]||0)+1.2;
  else if(ratio>=.3) topics[v.category]=(topics[v.category]||0)+.45;
  persistAll();
}
function toggleLike(id){
  if(isLiked(id)) likes=likes.filter(x=>x!==id);
  else {likes.push(id);const v=getVideo(id);if(v)topics[v.category]=(topics[v.category]||0)+1;}
  persistAll();renderAll();
  if(currentVideo?.id===id) updatePlayerLike();
  renderShortsActions();
}
function toggleSave(id){
  saves=isSaved(id)?saves.filter(x=>x!==id):[...saves,id];
  persistAll();
  const b=$("#saveVideoBtn");
  if(currentVideo?.id===id) b.textContent=isSaved(id)?"✓ Saved":"＋ Watch Later";
}
function updatePlayerLike(){
  $("#playerLikeBtn").textContent=isLiked(currentVideo?.id)?"♥":"♡";
  $("#playerLikeBtn").style.color=isLiked(currentVideo?.id)?"#e54b73":"";
}

function ensureLongPlayer(video, startSeconds=0){
  if(!window.YT || !YT.Player) return;
  if(longPlayer && longPlayer.destroy){try{longPlayer.destroy();}catch{}}
  $("#longPlayer").innerHTML="";
  longPlayer=new YT.Player("longPlayer",{
    videoId:video.youtubeId,
    playerVars:{autoplay:1,playsinline:1,rel:0,start:Math.floor(startSeconds)},
    events:{
      onReady:e=>{try{e.target.playVideo();}catch{}},
      onStateChange:e=>{
        if(e.data===YT.PlayerState.PLAYING) startLongTracking();
        else stopLongTracking(true);
        if(e.data===YT.PlayerState.ENDED){
          const dur=safePlayerDuration(e.target);
          addWatch(video.id,dur,dur);
        }
      }
    }
  });
}
function safePlayerDuration(player){
  try{return Math.floor(player.getDuration()||currentVideo?.duration||0);}catch{return currentVideo?.duration||0;}
}
function startLongTracking(){
  stopLongTracking(false);
  watchTimer=setInterval(()=>{
    if(!currentVideo||!longPlayer?.getCurrentTime)return;
    try{addWatch(currentVideo.id,Math.floor(longPlayer.getCurrentTime()),safePlayerDuration(longPlayer));}catch{}
  },5000);
}
function stopLongTracking(saveNow){
  if(watchTimer){clearInterval(watchTimer);watchTimer=null;}
  if(saveNow&&currentVideo&&longPlayer?.getCurrentTime){
    try{addWatch(currentVideo.id,Math.floor(longPlayer.getCurrentTime()),safePlayerDuration(longPlayer));}catch{}
  }
}
function openVideo(id){
  const v=getVideo(id);if(!v)return;
  if(v.type==="short"){navigate("shorts");return;}
  currentVideo=v;viewBeforePlayer=$$(".nav-item.active")[0]?.dataset.view||"home";
  $("#playerTitle").textContent=v.title;
  $("#playerMeta").textContent=`${v.channel} · ${v.category}`;
  $("#playerDescription").textContent=v.description||"";
  $("#saveVideoBtn").textContent=isSaved(v.id)?"✓ Saved":"＋ Watch Later";
  updatePlayerLike();
  $("#playerModal").hidden=false;
  document.body.style.overflow="hidden";
  const start=Number(progress[v.id]||0);
  ensureLongPlayer(v,start);
  addWatch(v.id,Math.max(Number(history[v.id]?.watchedSeconds||0),start),v.duration);
}
function closePlayer(){
  stopLongTracking(true);
  if(longPlayer&&longPlayer.destroy){try{longPlayer.destroy();}catch{}}
  longPlayer=null;$("#longPlayer").innerHTML="";
  $("#playerModal").hidden=true;document.body.style.overflow="";
  if(currentVideo&&history[currentVideo.id]) progress[currentVideo.id]=history[currentVideo.id].watchedSeconds||0;
  persistAll();currentVideo=null;
  renderAll();
}

function renderShorts(){
  const feed=$("#shortsFeed");
  if(feed.dataset.rendered==="1") { renderShortsActions(); return; }
  const shorts=orderedVideos(VIDEO_DATA.filter(v=>v.type==="short"));
  feed.innerHTML=shorts.map(v=>`<section class="short-item" data-short-id="${escapeHTML(v.id)}">
    <img class="short-backdrop" src="${thumb(v)}" alt="" loading="lazy">
    <div class="short-player" id="short-player-${escapeHTML(v.id)}"></div><div class="short-overlay"></div>
    <div class="short-meta"><span class="short-category">${escapeHTML(v.category)}</span><h3>${escapeHTML(v.title)}</h3><p>${escapeHTML(v.channel)} · ${escapeHTML(v.description||"")}</p></div>
    <div class="short-actions">
      <button class="short-action ${isLiked(v.id)?"liked":""}" data-like="${escapeHTML(v.id)}"><span>${isLiked(v.id)?"♥":"♡"}</span><small>${isLiked(v.id)?"Liked":"Like"}</small></button>
      <button class="short-action" data-save="${escapeHTML(v.id)}"><span>${isSaved(v.id)?"✓":"＋"}</span><small>${isSaved(v.id)?"Saved":"Save"}</small></button>
      <button class="short-action" data-share="${escapeHTML(v.id)}"><span>↗</span><small>Share</small></button>
    </div>
  </section>`).join("");
  feed.dataset.rendered="1";
  if(!shorts.length) $("#emptyShorts").hidden=false;
  if("IntersectionObserver" in window){
    const observer=new IntersectionObserver(entries=>{
      entries.forEach(entry=>{
        const id=entry.target.dataset.shortId;
        if(entry.isIntersecting && entry.intersectionRatio>=.65) activateShort(id);
        else if(entry.intersectionRatio<.25) pauseShort(id);
      });
    },{root:feed,threshold:[0,.25,.65,1]});
    $$(".short-item",feed).forEach(item=>observer.observe(item));
    feed._shortObserver=observer;
  }
  startVisibleShort();
}
function activateShort(id){
  const v=getVideo(id);if(!v)return;
  lastShortId=id;
  shortPlayers.forEach((p,pid)=>{if(pid!==id)try{p.pauseVideo();}catch{}});
  if(shortPlayers.has(id)){try{shortPlayers.get(id).playVideo();}catch{}return;}
  if(!window.YT||!YT.Player)return;
  const target=`short-player-${id}`;
  const host=document.getElementById(target);if(!host)return;
  const player=new YT.Player(target,{
    videoId:v.youtubeId,
    playerVars:{autoplay:1,playsinline:1,controls:1,rel:0,modestbranding:1},
    events:{
      onReady:e=>{try{e.target.mute();e.target.playVideo();}catch{}},
      onStateChange:e=>{
        if(e.data===YT.PlayerState.PLAYING) addWatch(v.id,Math.max(1,Math.floor(e.target.getCurrentTime()||0)),v.duration);
        if(e.data===YT.PlayerState.ENDED){addWatch(v.id,v.duration,v.duration);}
      }
    }
  });
  shortPlayers.set(id,player);
}
function pauseShort(id){const p=shortPlayers.get(id);if(p){try{p.pauseVideo();}catch{}}}
function startVisibleShort(){
  if(!$("#shortsView")||$("#shortsView").hidden)return;
  const items=$$(".short-item");
  if(!items.length)return;
  const feed=$("#shortsFeed"),mid=feed.scrollTop+feed.clientHeight*.5;
  let closest=null,dist=Infinity;
  items.forEach(item=>{const d=Math.abs(item.offsetTop+item.offsetHeight/2-mid);if(d<dist){dist=d;closest=item;}});
  if(closest)activateShort(closest.dataset.shortId);
}
function renderShortsActions(){
  $$(".short-action[data-like]").forEach(b=>{const liked=isLiked(b.dataset.like);b.classList.toggle("liked",liked);b.querySelector("span").textContent=liked?"♥":"♡";b.querySelector("small").textContent=liked?"Liked":"Like";});
  $$(".short-action[data-save]").forEach(b=>{const saved=isSaved(b.dataset.save);b.querySelector("span").textContent=saved?"✓":"＋";b.querySelector("small").textContent=saved?"Saved":"Save";});
}
function shareVideo(id){
  const v=getVideo(id);if(!v)return;
  const url=`https://www.youtube.com/watch?v=${encodeURIComponent(v.youtubeId)}`;
  if(navigator.share) navigator.share({title:v.title,text:"VibePlay पर यह वीडियो देखें",url}).catch(()=>{});
  else if(navigator.clipboard) navigator.clipboard.writeText(url).then(()=>alert("YouTube लिंक कॉपी हो गया।")).catch(()=>prompt("वीडियो लिंक:",url));
  else prompt("वीडियो लिंक:",url);
}

document.addEventListener("click",e=>{
  const nav=e.target.closest("[data-view]");if(nav){navigate(nav.dataset.view);return;}
  const cat=e.target.closest("[data-category]");if(cat){activeCategory=cat.dataset.category;renderHome();return;}
  const like=e.target.closest("[data-like]");if(like){e.stopPropagation();toggleLike(like.dataset.like);return;}
  const save=e.target.closest("[data-save]");if(save){e.stopPropagation();toggleSave(save.dataset.save);return;}
  const share=e.target.closest("[data-share]");if(share){shareVideo(share.dataset.share);return;}
  const card=e.target.closest("[data-open-video]");if(card){openVideo(card.dataset.openVideo);return;}
});
document.addEventListener("keydown",e=>{
  if((e.key==="Enter"||e.key===" ")&&e.target.matches("[data-open-video]")){e.preventDefault();openVideo(e.target.dataset.openVideo);}
  if(e.key==="Escape"&&!$("#playerModal").hidden)closePlayer();
});
$("#searchInput").addEventListener("input",()=>{renderHome();renderLiked();renderHistory();});
$("#sortBtn").addEventListener("click",()=>{sortMode=sortMode==="mixed"?"latest":"mixed";$("#sortBtn").textContent=sortMode==="latest"?"नई वीडियो पहले ↻":"मिक्स फ़ीड ↻";renderHome();});
$("#closePlayerBtn").addEventListener("click",closePlayer);
$("#playerModal").addEventListener("click",e=>{if(e.target===$("#playerModal"))closePlayer();});
$("#playerLikeBtn").addEventListener("click",()=>{if(currentVideo)toggleLike(currentVideo.id);});
$("#saveVideoBtn").addEventListener("click",()=>{if(currentVideo)toggleSave(currentVideo.id);});
$("#shortsBackBtn").addEventListener("click",()=>navigate("home"));
$("#shortsFeed").addEventListener("scroll",()=>{ /* Scroll Snap handles motion; observer handles active playback. */},{passive:true});
$("#clearHistoryBtn").addEventListener("click",()=>{
  if(confirm("क्या आप अपनी पूरी Watch History साफ़ करना चाहते हैं?")){
    history={};progress={};persistAll();renderHistory();
  }
});
$("#resetPrefsBtn").addEventListener("click",()=>{
  if(confirm("Likes, Watch History और recommendations रीसेट करें?")){
    likes=[];history={};saves=[];topics={};progress={};skips={};persistAll();renderAll();alert("आपकी स्थानीय पसंद रीसेट हो गई।");
  }
});
window.onYouTubeIframeAPIReady=()=>{if(!$("#shortsView").hidden)startVisibleShort();};
window.addEventListener("beforeinstallprompt",e=>{
  e.preventDefault();pendingInstallPrompt=e;$("#installBtn").hidden=false;
});
$("#installBtn").addEventListener("click",async()=>{
  if(!pendingInstallPrompt)return;
  pendingInstallPrompt.prompt();await pendingInstallPrompt.userChoice;
  pendingInstallPrompt=null;$("#installBtn").hidden=true;
});
window.addEventListener("pagehide",()=>stopLongTracking(true));
if("serviceWorker" in navigator && location.protocol.startsWith("http")){
  window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(err=>console.warn("Service worker registration failed",err)));
}
renderAll();
